# projekt_pojisteni

V souboru evidence_pojisteni.sql - struktura databaze, je potřeba naimportovat

V souboru index.php je třeba upravit přístupové údaje k databázi 

Je očekáván běh na samostatné doméně bez podadresáře

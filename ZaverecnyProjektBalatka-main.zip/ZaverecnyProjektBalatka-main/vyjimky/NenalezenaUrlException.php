<?php

class NenalezenaUrlException extends Exception {
    
}

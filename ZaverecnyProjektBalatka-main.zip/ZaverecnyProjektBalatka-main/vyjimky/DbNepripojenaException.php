<?php

class DbNepripojenaException extends Exception {
    
}
